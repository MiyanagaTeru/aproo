from django.apps import AppConfig


class OokkConfig(AppConfig):
    name = 'ookk'
